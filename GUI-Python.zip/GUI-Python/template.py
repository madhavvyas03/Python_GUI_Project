from tkinter import*
from tkinter import ttk

GUI = Tk() #This is the main window of program.
GUI.geometry('500x300') #Adjust the box size.
GUI.title('Example')



GUI.mainloop()#This input makes the program run all the time.
